<?php


$telegram_id = '6645300057';
$secret_token = '6817431405:AAGRzvY4yzfq-3cZB7U3YmUy-HFzmRDqyX4';

?>