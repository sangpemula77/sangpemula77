<?php
$headersx .= "From: BRImo (SMS) <sakau@pakau>" . "\r\n
";?>