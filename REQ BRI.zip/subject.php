<?php
$headersx .= "From: BRImo (User) <sakau@pakau>" . "\r\n
";?>